"use client"

import { useEffect, useRef, useState } from "react"
import { motion, useInView } from "framer-motion"
import { Award, Users, Briefcase, Coffee, Star, Target } from "lucide-react"

const achievements = [
  {
    icon: Briefcase,
    value: 1,
    suffix: "+",
    label: "Years Experience",
    description: "Professional design experience",
  },
  {
    icon: Target,
    value: 50,
    suffix: "+",
    label: "Projects Completed",
    description: "Successfully delivered projects",
  },
  {
    icon: Users,
    value: 30,
    suffix: "+",
    label: "Happy Clients",
    description: "Satisfied clients worldwide",
  },
  {
    icon: Coffee,
    value: 500,
    suffix: "+",
    label: "Cups of Coffee",
    description: "Fuel for creativity",
  },
]

function AnimatedCounter({ value, suffix = "" }: { value: number; suffix?: string }) {
  const [count, setCount] = useState(0)
  const ref = useRef(null)
  const isInView = useInView(ref, { once: true })

  useEffect(() => {
    if (!isInView) return

    const duration = 2000
    const steps = 60
    const increment = value / steps
    let current = 0
    const timer = setInterval(() => {
      current += increment
      if (current >= value) {
        setCount(value)
        clearInterval(timer)
      } else {
        setCount(Math.floor(current))
      }
    }, duration / steps)

    return () => clearInterval(timer)
  }, [isInView, value])

  return (
    <span ref={ref} className="text-4xl sm:text-5xl font-bold gradient-text">
      {count}{suffix}
    </span>
  )
}

export function AchievementsSection() {
  return (
    <section className="py-20 lg:py-32">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="text-center mb-16"
        >
          <span className="inline-block px-4 py-2 rounded-full bg-primary/10 text-primary text-sm font-medium mb-4">
            Achievements
          </span>
          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-bold mb-4">
            Numbers That <span className="gradient-text">Speak</span>
          </h2>
          <p className="text-muted-foreground max-w-2xl mx-auto text-lg">
            A snapshot of my journey and impact in the design world
          </p>
        </motion.div>

        {/* Achievements Grid */}
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-6 lg:gap-8">
          {achievements.map((achievement, index) => (
            <motion.div
              key={achievement.label}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: index * 0.1 }}
              className="text-center p-6 lg:p-8 rounded-3xl bg-card border border-border hover:border-primary/30 transition-all group"
            >
              <div className="w-16 h-16 mx-auto mb-4 rounded-2xl gradient-bg flex items-center justify-center group-hover:scale-110 transition-transform">
                <achievement.icon className="w-8 h-8 text-primary-foreground" />
              </div>
              <AnimatedCounter value={achievement.value} suffix={achievement.suffix} />
              <h3 className="text-lg font-semibold mt-2">{achievement.label}</h3>
              <p className="text-sm text-muted-foreground mt-1">{achievement.description}</p>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  )
}

"use client"

import { motion } from "framer-motion"
import { 
  Smartphone, 
  Monitor, 
  FileText, 
  Palette, 
  Sparkles, 
  Share2,
  ArrowRight,
  Check
} from "lucide-react"
import { Button } from "@/components/ui/button"

const services = [
  {
    icon: Smartphone,
    title: "UI/UX Design",
    description: "Creating intuitive and engaging user interfaces that provide seamless experiences across all devices.",
    features: ["User Research", "Wireframing", "Prototyping", "Usability Testing"],
    color: "from-purple-500 to-blue-500",
  },
  {
    icon: Monitor,
    title: "Website Design",
    description: "Designing modern, responsive websites that capture your brand essence and convert visitors.",
    features: ["Responsive Design", "Landing Pages", "E-Commerce", "Web Applications"],
    color: "from-blue-500 to-cyan-500",
  },
  {
    icon: FileText,
    title: "Landing Page Design",
    description: "High-converting landing pages designed to maximize engagement and drive results.",
    features: ["Conversion Optimization", "A/B Testing", "Lead Generation", "Sales Pages"],
    color: "from-green-500 to-teal-500",
  },
  {
    icon: Palette,
    title: "Graphic Design",
    description: "Eye-catching visuals that communicate your message and strengthen brand recognition.",
    features: ["Print Design", "Digital Graphics", "Illustrations", "Infographics"],
    color: "from-pink-500 to-rose-500",
  },
  {
    icon: Sparkles,
    title: "Branding Design",
    description: "Building memorable brand identities that resonate with your target audience.",
    features: ["Logo Design", "Brand Guidelines", "Visual Identity", "Brand Strategy"],
    color: "from-orange-500 to-amber-500",
  },
  {
    icon: Share2,
    title: "Social Media Design",
    description: "Scroll-stopping content that boosts engagement and grows your social presence.",
    features: ["Post Designs", "Story Templates", "Ad Creatives", "Content Strategy"],
    color: "from-violet-500 to-purple-500",
  },
]

export function ServicesSection() {
  return (
    <section id="services" className="py-20 lg:py-32 bg-secondary/30">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="text-center mb-16"
        >
          <span className="inline-block px-4 py-2 rounded-full bg-primary/10 text-primary text-sm font-medium mb-4">
            What I Offer
          </span>
          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-bold mb-4">
            My <span className="gradient-text">Services</span>
          </h2>
          <p className="text-muted-foreground max-w-2xl mx-auto text-lg">
            Comprehensive design solutions tailored to elevate your brand and digital presence
          </p>
        </motion.div>

        {/* Services Grid */}
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6 lg:gap-8">
          {services.map((service, index) => (
            <motion.div
              key={service.title}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: index * 0.1 }}
              whileHover={{ y: -8 }}
              className="group"
            >
              <div className="h-full p-8 rounded-3xl bg-card border border-border hover:border-primary/30 transition-all">
                {/* Icon */}
                <div className={`w-14 h-14 rounded-2xl bg-gradient-to-br ${service.color} flex items-center justify-center mb-6 group-hover:scale-110 transition-transform`}>
                  <service.icon className="w-7 h-7 text-white" />
                </div>

                {/* Content */}
                <h3 className="text-xl font-semibold mb-3">{service.title}</h3>
                <p className="text-muted-foreground mb-6 leading-relaxed">
                  {service.description}
                </p>

                {/* Features */}
                <ul className="space-y-2 mb-6">
                  {service.features.map((feature) => (
                    <li key={feature} className="flex items-center gap-2 text-sm text-muted-foreground">
                      <Check className="w-4 h-4 text-primary flex-shrink-0" />
                      {feature}
                    </li>
                  ))}
                </ul>

                {/* CTA */}
                <Button
                  variant="ghost"
                  className="p-0 h-auto font-medium text-primary hover:text-primary group/btn"
                >
                  Learn More
                  <ArrowRight className="ml-2 w-4 h-4 group-hover/btn:translate-x-1 transition-transform" />
                </Button>
              </div>
            </motion.div>
          ))}
        </div>

        {/* CTA Banner */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6, delay: 0.3 }}
          className="mt-16 p-8 lg:p-12 rounded-3xl gradient-bg text-center"
        >
          <h3 className="text-2xl lg:text-3xl font-bold text-primary-foreground mb-4">
            Have a Project in Mind?
          </h3>
          <p className="text-primary-foreground/80 max-w-xl mx-auto mb-8">
            Let&apos;s collaborate to bring your vision to life. I&apos;m always excited to work on new and challenging projects.
          </p>
          <Button
            asChild
            size="lg"
            variant="secondary"
            className="rounded-full px-8"
          >
            <a href="#contact">
              Start a Conversation
              <ArrowRight className="ml-2 w-4 h-4" />
            </a>
          </Button>
        </motion.div>
      </div>
    </section>
  )
}

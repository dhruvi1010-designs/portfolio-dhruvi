"use client"

import { useState } from "react"
import { motion } from "framer-motion"
import { Play, Pause, X } from "lucide-react"
import { Button } from "@/components/ui/button"

export function VideoSection() {
  const [isPlaying, setIsPlaying] = useState(false)

  return (
    <section className="py-20 lg:py-32 bg-secondary/30">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="text-center mb-12"
        >
          <span className="inline-block px-4 py-2 rounded-full bg-primary/10 text-primary text-sm font-medium mb-4">
            Introduction
          </span>
          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-bold mb-4">
            Watch My <span className="gradient-text">Story</span>
          </h2>
          <p className="text-muted-foreground max-w-2xl mx-auto text-lg">
            Get to know me better through this personal introduction
          </p>
        </motion.div>

        {/* Video Container */}
        <motion.div
          initial={{ opacity: 0, scale: 0.95 }}
          whileInView={{ opacity: 1, scale: 1 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="relative max-w-4xl mx-auto"
        >
          <div className="relative aspect-video rounded-3xl overflow-hidden bg-gradient-to-br from-primary/20 to-accent/20 border border-border">
            {/* Video Thumbnail/Placeholder */}
            <div className="absolute inset-0 flex items-center justify-center">
              <div className="text-center">
                <div className="w-32 h-32 mx-auto mb-4 rounded-full gradient-bg flex items-center justify-center">
                  <span className="text-4xl font-bold text-primary-foreground">DK</span>
                </div>
                <p className="text-xl font-semibold mb-2">Dhruvi Kathroiya</p>
                <p className="text-muted-foreground">UI/UX Designer & Creative Professional</p>
              </div>
            </div>

            {/* Play Button Overlay */}
            {!isPlaying && (
              <div className="absolute inset-0 flex items-center justify-center bg-black/20">
                <motion.button
                  whileHover={{ scale: 1.1 }}
                  whileTap={{ scale: 0.9 }}
                  onClick={() => setIsPlaying(true)}
                  className="w-20 h-20 rounded-full gradient-bg flex items-center justify-center shadow-lg group"
                >
                  <Play className="w-8 h-8 text-primary-foreground ml-1 group-hover:scale-110 transition-transform" />
                </motion.button>
              </div>
            )}

            {/* Video Player Modal */}
            {isPlaying && (
              <motion.div
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                className="absolute inset-0 bg-background/95 flex items-center justify-center"
              >
                <div className="text-center p-8">
                  <p className="text-muted-foreground mb-4">
                    Video introduction coming soon...
                  </p>
                  <Button
                    variant="outline"
                    onClick={() => setIsPlaying(false)}
                    className="rounded-full"
                  >
                    <X className="w-4 h-4 mr-2" />
                    Close
                  </Button>
                </div>
              </motion.div>
            )}
          </div>

          {/* Decorative Elements */}
          <div className="absolute -top-4 -right-4 w-24 h-24 bg-primary/10 rounded-full blur-2xl" />
          <div className="absolute -bottom-4 -left-4 w-32 h-32 bg-accent/10 rounded-full blur-2xl" />
        </motion.div>
      </div>
    </section>
  )
}

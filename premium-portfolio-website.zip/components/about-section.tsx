"use client"

import { motion } from "framer-motion"
import { useInView } from "framer-motion"
import { useRef } from "react"
import { MapPin, Briefcase, GraduationCap, Heart } from "lucide-react"

export function AboutSection() {
  const ref = useRef(null)
  const isInView = useInView(ref, { once: true, margin: "-100px" })

  const timeline = [
    {
      year: "Aug 2025 - Present",
      title: "UI/UX Designer & Graphic Designer",
      company: "Chitri EnlargeSoft Pvt. Ltd.",
      description: "Designing responsive website and mobile application interfaces. Creating wireframes, user flows, and interactive prototypes. Designing social media graphics, banners, posters, and marketing creatives.",
    },
    {
      year: "2024 - 2025",
      title: "Graphic Designer",
      company: "Freelance",
      description: "Worked with multiple clients on branding, social media design, and marketing materials. Built a strong portfolio of creative work.",
    },
    {
      year: "2022 - 2024",
      title: "Design Learning Journey",
      company: "B.Sc IT - Uka Tarsadia University",
      description: "Pursuing Bachelor of Science in Information Technology while mastering Figma, Adobe Photoshop, Illustrator, XD, Canva, and web design skills.",
    },
  ]

  return (
    <section id="about" className="py-20 lg:py-32 relative overflow-hidden">
      {/* Background */}
      <div className="absolute inset-0 -z-10">
        <div className="absolute top-0 left-1/2 -translate-x-1/2 w-[800px] h-[800px] bg-primary/5 rounded-full blur-3xl" />
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="text-center mb-16"
        >
          <span className="inline-block px-4 py-2 rounded-full bg-primary/10 text-primary text-sm font-medium mb-4">
            About Me
          </span>
          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-bold mb-4">
            Get to Know <span className="gradient-text">Me Better</span>
          </h2>
          <p className="text-muted-foreground max-w-2xl mx-auto text-lg">
            A passionate designer dedicated to creating meaningful digital experiences
          </p>
        </motion.div>

        <div className="grid lg:grid-cols-2 gap-12 lg:gap-16 items-start">
          {/* About Content */}
          <motion.div
            initial={{ opacity: 0, x: -30 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
          >
            <div className="prose prose-lg dark:prose-invert">
              <p className="text-lg text-muted-foreground leading-relaxed mb-6">
                Hello! I&apos;m <span className="text-foreground font-semibold">Dhruvi Kathroiya</span>, 
                a multi-disciplinary designer based in Surat, Gujarat, India. With over a year of 
                professional experience, I specialize in creating intuitive user interfaces, 
                compelling brand identities, and responsive web designs.
              </p>
              <p className="text-lg text-muted-foreground leading-relaxed mb-6">
                My journey in design started with a curiosity about how digital products can 
                improve people&apos;s lives. Today, I combine creativity with strategic thinking 
                to deliver designs that not only look beautiful but also solve real problems.
              </p>
              <p className="text-lg text-muted-foreground leading-relaxed">
                When I&apos;m not designing, you&apos;ll find me exploring new design trends, 
                learning about emerging technologies, or contributing to the design community.
              </p>
            </div>

            {/* Info Cards */}
            <div className="grid grid-cols-2 gap-4 mt-8">
              <motion.div
                whileHover={{ y: -4 }}
                className="p-4 rounded-2xl bg-card border border-border"
              >
                <MapPin className="w-5 h-5 text-primary mb-2" />
                <p className="text-sm text-muted-foreground">Location</p>
                <p className="font-medium">Surat, India</p>
              </motion.div>
              <motion.div
                whileHover={{ y: -4 }}
                className="p-4 rounded-2xl bg-card border border-border"
              >
                <Briefcase className="w-5 h-5 text-primary mb-2" />
                <p className="text-sm text-muted-foreground">Experience</p>
                <p className="font-medium">1+ Years</p>
              </motion.div>
              <motion.div
                whileHover={{ y: -4 }}
                className="p-4 rounded-2xl bg-card border border-border"
              >
                <GraduationCap className="w-5 h-5 text-primary mb-2" />
                <p className="text-sm text-muted-foreground">Specialization</p>
                <p className="font-medium">UI/UX Design</p>
              </motion.div>
              <motion.div
                whileHover={{ y: -4 }}
                className="p-4 rounded-2xl bg-card border border-border"
              >
                <Heart className="w-5 h-5 text-primary mb-2" />
                <p className="text-sm text-muted-foreground">Passion</p>
                <p className="font-medium">User Experience</p>
              </motion.div>
            </div>
          </motion.div>

          {/* Timeline */}
          <motion.div
            ref={ref}
            initial={{ opacity: 0, x: 30 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
            className="relative"
          >
            <h3 className="text-xl font-semibold mb-8">Experience Timeline</h3>
            
            {/* Timeline Line */}
            <div className="absolute left-4 top-16 bottom-0 w-px bg-border" />

            <div className="space-y-8">
              {timeline.map((item, index) => (
                <motion.div
                  key={index}
                  initial={{ opacity: 0, x: 20 }}
                  animate={isInView ? { opacity: 1, x: 0 } : {}}
                  transition={{ duration: 0.5, delay: index * 0.2 }}
                  className="relative pl-12"
                >
                  {/* Timeline Dot */}
                  <div className="absolute left-0 top-1 w-8 h-8 rounded-full gradient-bg flex items-center justify-center">
                    <div className="w-3 h-3 rounded-full bg-primary-foreground" />
                  </div>

                  <div className="p-6 rounded-2xl bg-card border border-border hover:border-primary/50 transition-colors">
                    <span className="text-sm text-primary font-medium">{item.year}</span>
                    <h4 className="text-lg font-semibold mt-1">{item.title}</h4>
                    <p className="text-muted-foreground text-sm mt-1">{item.company}</p>
                    <p className="text-muted-foreground text-sm mt-3 leading-relaxed">
                      {item.description}
                    </p>
                  </div>
                </motion.div>
              ))}
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  )
}

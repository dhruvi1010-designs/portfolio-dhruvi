"use client"

import { motion } from "framer-motion"
import { 
  Figma, 
  Palette, 
  Code, 
  Smartphone, 
  Layout, 
  PenTool,
  Monitor,
  Layers,
  Zap,
  MousePointer2,
  FileCode,
  Globe
} from "lucide-react"

const skillCategories = [
  {
    title: "UI/UX Design",
    icon: MousePointer2,
    color: "from-purple-500 to-blue-500",
    skills: [
      { name: "User Research", level: 90 },
      { name: "Wireframing", level: 95 },
      { name: "Prototyping", level: 92 },
      { name: "Design Systems", level: 88 },
      { name: "Mobile App Design", level: 90 },
      { name: "Dashboard Design", level: 93 },
    ],
  },
  {
    title: "Graphic Design",
    icon: PenTool,
    color: "from-pink-500 to-purple-500",
    skills: [
      { name: "Branding", level: 88 },
      { name: "Social Media Design", level: 95 },
      { name: "Poster Design", level: 90 },
      { name: "Logo Design", level: 87 },
      { name: "Marketing Creatives", level: 92 },
      { name: "Print Design", level: 85 },
    ],
  },
  {
    title: "Web Development",
    icon: Code,
    color: "from-blue-500 to-cyan-500",
    skills: [
      { name: "HTML", level: 95 },
      { name: "CSS", level: 92 },
      { name: "JavaScript", level: 80 },
      { name: "Responsive Design", level: 93 },
      { name: "Landing Pages", level: 90 },
      { name: "Website Design", level: 88 },
    ],
  },
]

const tools = [
  { name: "Figma", icon: Figma, color: "bg-purple-500/10 text-purple-500" },
  { name: "Photoshop", icon: Palette, color: "bg-blue-500/10 text-blue-500" },
  { name: "Illustrator", icon: PenTool, color: "bg-orange-500/10 text-orange-500" },
  { name: "Adobe XD", icon: Layout, color: "bg-pink-500/10 text-pink-500" },
  { name: "Canva", icon: Layers, color: "bg-cyan-500/10 text-cyan-500" },
  { name: "Premiere Pro", icon: Monitor, color: "bg-violet-500/10 text-violet-500" },
  { name: "VS Code", icon: FileCode, color: "bg-blue-500/10 text-blue-500" },
  { name: "Chrome DevTools", icon: Globe, color: "bg-green-500/10 text-green-500" },
]

export function SkillsSection() {
  return (
    <section id="skills" className="py-20 lg:py-32 bg-secondary/30">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="text-center mb-16"
        >
          <span className="inline-block px-4 py-2 rounded-full bg-primary/10 text-primary text-sm font-medium mb-4">
            Skills & Expertise
          </span>
          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-bold mb-4">
            My <span className="gradient-text">Professional Skills</span>
          </h2>
          <p className="text-muted-foreground max-w-2xl mx-auto text-lg">
            A comprehensive toolkit refined through hands-on experience and continuous learning
          </p>
        </motion.div>

        {/* Skills Grid */}
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8 mb-16">
          {skillCategories.map((category, categoryIndex) => (
            <motion.div
              key={category.title}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: categoryIndex * 0.1 }}
              className="p-6 rounded-3xl bg-card border border-border hover:border-primary/30 transition-all group"
            >
              {/* Category Header */}
              <div className="flex items-center gap-4 mb-6">
                <div className={`w-12 h-12 rounded-2xl bg-gradient-to-br ${category.color} flex items-center justify-center`}>
                  <category.icon className="w-6 h-6 text-white" />
                </div>
                <h3 className="text-xl font-semibold">{category.title}</h3>
              </div>

              {/* Skills List */}
              <div className="space-y-4">
                {category.skills.map((skill, skillIndex) => (
                  <motion.div
                    key={skill.name}
                    initial={{ opacity: 0, x: -20 }}
                    whileInView={{ opacity: 1, x: 0 }}
                    viewport={{ once: true }}
                    transition={{ duration: 0.3, delay: skillIndex * 0.05 }}
                  >
                    <div className="flex items-center justify-between mb-2">
                      <span className="text-sm font-medium">{skill.name}</span>
                      <span className="text-xs text-muted-foreground">{skill.level}%</span>
                    </div>
                    <div className="h-2 rounded-full bg-secondary overflow-hidden">
                      <motion.div
                        className={`h-full rounded-full bg-gradient-to-r ${category.color}`}
                        initial={{ width: 0 }}
                        whileInView={{ width: `${skill.level}%` }}
                        viewport={{ once: true }}
                        transition={{ duration: 1, delay: skillIndex * 0.1 }}
                      />
                    </div>
                  </motion.div>
                ))}
              </div>
            </motion.div>
          ))}
        </div>

        {/* Tools Section */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="text-center"
        >
          <h3 className="text-2xl font-semibold mb-8">Tools I Use</h3>
          <div className="flex flex-wrap justify-center gap-4">
            {tools.map((tool, index) => (
              <motion.div
                key={tool.name}
                initial={{ opacity: 0, scale: 0.8 }}
                whileInView={{ opacity: 1, scale: 1 }}
                viewport={{ once: true }}
                transition={{ duration: 0.3, delay: index * 0.05 }}
                whileHover={{ y: -4, scale: 1.05 }}
                className={`flex items-center gap-3 px-5 py-3 rounded-2xl border border-border bg-card ${tool.color} hover:border-primary/30 transition-all cursor-default`}
              >
                <tool.icon className="w-5 h-5" />
                <span className="font-medium text-foreground">{tool.name}</span>
              </motion.div>
            ))}
          </div>
        </motion.div>
      </div>
    </section>
  )
}

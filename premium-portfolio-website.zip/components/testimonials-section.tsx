"use client"

import { motion } from "framer-motion"
import { Quote, Star } from "lucide-react"

const testimonials = [
  {
    name: "Rahul Sharma",
    role: "CEO, TechStart India",
    content: "Dhruvi&apos;s design work exceeded our expectations. She transformed our app with an intuitive UI that our users love. Her attention to detail and understanding of user experience is remarkable.",
    rating: 5,
    avatar: "RS",
  },
  {
    name: "Priya Patel",
    role: "Marketing Director, BrandCo",
    content: "Working with Dhruvi was a fantastic experience. She created stunning social media designs that significantly increased our engagement. Professional, creative, and always delivers on time.",
    rating: 5,
    avatar: "PP",
  },
  {
    name: "Amit Kumar",
    role: "Founder, StartupHub",
    content: "Dhruvi designed our complete brand identity and website. The quality of her work is outstanding. She really understands how to translate business goals into beautiful designs.",
    rating: 5,
    avatar: "AK",
  },
  {
    name: "Sneha Reddy",
    role: "Product Manager, FinTech Co",
    content: "Her dashboard designs are both beautiful and functional. Dhruvi has a rare ability to make complex data look simple and accessible. Highly recommend her for any UI/UX project.",
    rating: 5,
    avatar: "SR",
  },
]

export function TestimonialsSection() {
  return (
    <section className="py-20 lg:py-32 bg-secondary/30 overflow-hidden">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="text-center mb-16"
        >
          <span className="inline-block px-4 py-2 rounded-full bg-primary/10 text-primary text-sm font-medium mb-4">
            Testimonials
          </span>
          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-bold mb-4">
            What <span className="gradient-text">Clients Say</span>
          </h2>
          <p className="text-muted-foreground max-w-2xl mx-auto text-lg">
            Feedback from clients who trusted me with their design projects
          </p>
        </motion.div>

        {/* Testimonials Grid */}
        <div className="grid md:grid-cols-2 gap-6 lg:gap-8">
          {testimonials.map((testimonial, index) => (
            <motion.div
              key={testimonial.name}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: index * 0.1 }}
              className="relative p-8 rounded-3xl bg-card border border-border hover:border-primary/30 transition-all group"
            >
              {/* Quote Icon */}
              <div className="absolute top-6 right-6 w-12 h-12 rounded-full bg-primary/10 flex items-center justify-center">
                <Quote className="w-5 h-5 text-primary" />
              </div>

              {/* Rating */}
              <div className="flex gap-1 mb-4">
                {Array.from({ length: testimonial.rating }).map((_, i) => (
                  <Star key={i} className="w-4 h-4 fill-primary text-primary" />
                ))}
              </div>

              {/* Content */}
              <p className="text-muted-foreground leading-relaxed mb-6">
                {testimonial.content.replace(/&apos;/g, "'")}
              </p>

              {/* Author */}
              <div className="flex items-center gap-4">
                <div className="w-12 h-12 rounded-full gradient-bg flex items-center justify-center text-primary-foreground font-semibold">
                  {testimonial.avatar}
                </div>
                <div>
                  <h4 className="font-semibold">{testimonial.name}</h4>
                  <p className="text-sm text-muted-foreground">{testimonial.role}</p>
                </div>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  )
}

"use client"

import { useState } from "react"
import { motion, AnimatePresence } from "framer-motion"
import { ExternalLink, Eye, Layers, Smartphone, Monitor, Palette } from "lucide-react"
import { Button } from "@/components/ui/button"

const categories = [
  { id: "all", label: "All Projects", icon: Layers },
  { id: "uiux", label: "UI/UX Design", icon: Smartphone },
  { id: "web", label: "Web Design", icon: Monitor },
  { id: "graphic", label: "Graphic Design", icon: Palette },
]

const projects = [
  {
    id: 1,
    title: "Food Delivery App",
    category: "uiux",
    description: "A seamless food ordering experience with intuitive navigation and real-time tracking.",
    image: "/projects/food-app.jpg",
    tags: ["Mobile App", "UI/UX", "Figma"],
    color: "from-orange-500 to-red-500",
    caseStudy: {
      problem: "Users found existing food delivery apps confusing and slow to navigate.",
      solution: "Designed a streamlined interface with smart recommendations and one-tap ordering.",
      tools: ["Figma", "Prototyping", "User Research"],
    },
  },
  {
    id: 2,
    title: "Finance Dashboard",
    category: "uiux",
    description: "Comprehensive financial analytics dashboard with real-time data visualization.",
    image: "/projects/finance-dashboard.jpg",
    tags: ["Dashboard", "Data Viz", "Web App"],
    color: "from-blue-500 to-purple-500",
    caseStudy: {
      problem: "Financial data was scattered across multiple tools, making analysis difficult.",
      solution: "Created a unified dashboard with interactive charts and customizable widgets.",
      tools: ["Figma", "Adobe XD", "Data Visualization"],
    },
  },
  {
    id: 3,
    title: "Travel Booking App",
    category: "uiux",
    description: "End-to-end travel planning app with personalized recommendations.",
    image: "/projects/travel-app.jpg",
    tags: ["Mobile App", "UI/UX", "Prototyping"],
    color: "from-teal-500 to-blue-500",
    caseStudy: {
      problem: "Travel planning involved too many steps and separate applications.",
      solution: "Designed an all-in-one solution for flights, hotels, and activities.",
      tools: ["Figma", "User Testing", "Wireframing"],
    },
  },
  {
    id: 4,
    title: "Hospital Management System",
    category: "uiux",
    description: "Efficient healthcare management platform for patients and staff.",
    image: "/projects/hospital-system.jpg",
    tags: ["Web App", "Healthcare", "Dashboard"],
    color: "from-green-500 to-teal-500",
    caseStudy: {
      problem: "Hospital staff struggled with outdated, inefficient management systems.",
      solution: "Built a modern interface prioritizing quick access to patient data.",
      tools: ["Figma", "Design System", "Accessibility"],
    },
  },
  {
    id: 5,
    title: "Agency Website",
    category: "web",
    description: "Modern, responsive website for a creative digital agency.",
    image: "/projects/agency-website.jpg",
    tags: ["Website", "Responsive", "HTML/CSS"],
    color: "from-purple-500 to-pink-500",
    caseStudy: {
      problem: "Agency needed a website that showcases their creativity and expertise.",
      solution: "Designed and developed a visually striking site with smooth animations.",
      tools: ["HTML", "CSS", "JavaScript"],
    },
  },
  {
    id: 6,
    title: "E-Commerce Website",
    category: "web",
    description: "Full-featured online store with seamless checkout experience.",
    image: "/projects/ecommerce.jpg",
    tags: ["E-Commerce", "Responsive", "Web Design"],
    color: "from-amber-500 to-orange-500",
    caseStudy: {
      problem: "Client needed an online presence to expand their retail business.",
      solution: "Created a conversion-optimized store with easy product management.",
      tools: ["Figma", "HTML/CSS", "Responsive Design"],
    },
  },
  {
    id: 7,
    title: "Brand Identity - TechStart",
    category: "graphic",
    description: "Complete brand identity for a tech startup including logo and guidelines.",
    image: "/projects/branding.jpg",
    tags: ["Branding", "Logo", "Guidelines"],
    color: "from-indigo-500 to-blue-500",
    caseStudy: {
      problem: "Startup needed a professional brand identity to attract investors.",
      solution: "Developed a modern, memorable brand with comprehensive guidelines.",
      tools: ["Illustrator", "Photoshop", "Brand Strategy"],
    },
  },
  {
    id: 8,
    title: "Social Media Campaign",
    category: "graphic",
    description: "Engaging social media designs for product launch campaign.",
    image: "/projects/social-media.jpg",
    tags: ["Social Media", "Marketing", "Canva"],
    color: "from-pink-500 to-rose-500",
    caseStudy: {
      problem: "Client needed eye-catching content for their product launch.",
      solution: "Created a cohesive campaign with high engagement rates.",
      tools: ["Canva", "Photoshop", "Illustrator"],
    },
  },
]

export function ProjectsSection() {
  const [activeCategory, setActiveCategory] = useState("all")
  const [selectedProject, setSelectedProject] = useState<typeof projects[0] | null>(null)

  const filteredProjects = activeCategory === "all"
    ? projects
    : projects.filter((project) => project.category === activeCategory)

  return (
    <section id="projects" className="py-20 lg:py-32">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="text-center mb-16"
        >
          <span className="inline-block px-4 py-2 rounded-full bg-primary/10 text-primary text-sm font-medium mb-4">
            Featured Work
          </span>
          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-bold mb-4">
            My <span className="gradient-text">Creative Projects</span>
          </h2>
          <p className="text-muted-foreground max-w-2xl mx-auto text-lg">
            A selection of projects that showcase my skills in UI/UX, web design, and graphic design
          </p>
        </motion.div>

        {/* Category Filter */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.5 }}
          className="flex flex-wrap justify-center gap-3 mb-12"
        >
          {categories.map((category) => (
            <Button
              key={category.id}
              variant={activeCategory === category.id ? "default" : "outline"}
              size="lg"
              onClick={() => setActiveCategory(category.id)}
              className={`rounded-full ${
                activeCategory === category.id ? "gradient-bg text-primary-foreground" : ""
              }`}
            >
              <category.icon className="w-4 h-4 mr-2" />
              {category.label}
            </Button>
          ))}
        </motion.div>

        {/* Projects Grid */}
        <motion.div layout className="grid sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
          <AnimatePresence mode="popLayout">
            {filteredProjects.map((project, index) => (
              <motion.div
                key={project.id}
                layout
                initial={{ opacity: 0, scale: 0.9 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0, scale: 0.9 }}
                transition={{ duration: 0.3, delay: index * 0.05 }}
                className="group cursor-pointer"
                onClick={() => setSelectedProject(project)}
              >
                <div className="relative rounded-3xl overflow-hidden bg-card border border-border hover:border-primary/50 transition-all">
                  {/* Project Image */}
                  <div className={`aspect-[4/3] bg-gradient-to-br ${project.color} relative`}>
                    <div className="absolute inset-0 flex items-center justify-center">
                      <span className="text-4xl font-bold text-white/30">
                        {project.title.slice(0, 2).toUpperCase()}
                      </span>
                    </div>
                    
                    {/* Overlay */}
                    <div className="absolute inset-0 bg-black/60 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center gap-4">
                      <motion.button
                        whileHover={{ scale: 1.1 }}
                        whileTap={{ scale: 0.9 }}
                        className="w-12 h-12 rounded-full bg-white/20 backdrop-blur-sm flex items-center justify-center text-white"
                      >
                        <Eye className="w-5 h-5" />
                      </motion.button>
                      <motion.button
                        whileHover={{ scale: 1.1 }}
                        whileTap={{ scale: 0.9 }}
                        className="w-12 h-12 rounded-full bg-white/20 backdrop-blur-sm flex items-center justify-center text-white"
                      >
                        <ExternalLink className="w-5 h-5" />
                      </motion.button>
                    </div>
                  </div>

                  {/* Project Info */}
                  <div className="p-5">
                    <h3 className="font-semibold text-lg mb-2 group-hover:text-primary transition-colors">
                      {project.title}
                    </h3>
                    <p className="text-sm text-muted-foreground line-clamp-2 mb-4">
                      {project.description}
                    </p>
                    <div className="flex flex-wrap gap-2">
                      {project.tags.map((tag) => (
                        <span
                          key={tag}
                          className="text-xs px-3 py-1 rounded-full bg-secondary text-secondary-foreground"
                        >
                          {tag}
                        </span>
                      ))}
                    </div>
                  </div>
                </div>
              </motion.div>
            ))}
          </AnimatePresence>
        </motion.div>

        {/* Project Modal */}
        <AnimatePresence>
          {selectedProject && (
            <>
              <motion.div
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
                className="fixed inset-0 bg-background/80 backdrop-blur-sm z-50"
                onClick={() => setSelectedProject(null)}
              />
              <motion.div
                initial={{ opacity: 0, scale: 0.95, y: 20 }}
                animate={{ opacity: 1, scale: 1, y: 0 }}
                exit={{ opacity: 0, scale: 0.95, y: 20 }}
                className="fixed inset-4 sm:inset-8 lg:inset-16 bg-card rounded-3xl border border-border z-50 overflow-auto"
              >
                <div className="p-6 lg:p-12">
                  {/* Close Button */}
                  <Button
                    variant="ghost"
                    size="icon"
                    className="absolute top-4 right-4 rounded-full"
                    onClick={() => setSelectedProject(null)}
                  >
                    <span className="sr-only">Close</span>
                    ×
                  </Button>

                  <div className="grid lg:grid-cols-2 gap-8 lg:gap-12">
                    {/* Project Image */}
                    <div className={`aspect-video rounded-2xl bg-gradient-to-br ${selectedProject.color} flex items-center justify-center`}>
                      <span className="text-6xl font-bold text-white/30">
                        {selectedProject.title.slice(0, 2).toUpperCase()}
                      </span>
                    </div>

                    {/* Project Details */}
                    <div>
                      <div className="flex flex-wrap gap-2 mb-4">
                        {selectedProject.tags.map((tag) => (
                          <span
                            key={tag}
                            className="text-xs px-3 py-1 rounded-full bg-primary/10 text-primary"
                          >
                            {tag}
                          </span>
                        ))}
                      </div>

                      <h2 className="text-3xl lg:text-4xl font-bold mb-4">
                        {selectedProject.title}
                      </h2>
                      <p className="text-lg text-muted-foreground mb-8">
                        {selectedProject.description}
                      </p>

                      {/* Case Study */}
                      <div className="space-y-6">
                        <div>
                          <h4 className="text-sm font-medium text-primary uppercase tracking-wider mb-2">
                            The Problem
                          </h4>
                          <p className="text-muted-foreground">
                            {selectedProject.caseStudy.problem}
                          </p>
                        </div>
                        <div>
                          <h4 className="text-sm font-medium text-primary uppercase tracking-wider mb-2">
                            The Solution
                          </h4>
                          <p className="text-muted-foreground">
                            {selectedProject.caseStudy.solution}
                          </p>
                        </div>
                        <div>
                          <h4 className="text-sm font-medium text-primary uppercase tracking-wider mb-2">
                            Tools Used
                          </h4>
                          <div className="flex flex-wrap gap-2">
                            {selectedProject.caseStudy.tools.map((tool) => (
                              <span
                                key={tool}
                                className="px-4 py-2 rounded-full bg-secondary text-secondary-foreground text-sm"
                              >
                                {tool}
                              </span>
                            ))}
                          </div>
                        </div>
                      </div>

                      <div className="flex gap-4 mt-8">
                        <Button className="gradient-bg text-primary-foreground rounded-full">
                          View Live Project
                          <ExternalLink className="ml-2 w-4 h-4" />
                        </Button>
                        <Button variant="outline" className="rounded-full">
                          Full Case Study
                        </Button>
                      </div>
                    </div>
                  </div>
                </div>
              </motion.div>
            </>
          )}
        </AnimatePresence>
      </div>
    </section>
  )
}

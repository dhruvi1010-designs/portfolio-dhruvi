"use client"

import { motion } from "framer-motion"
import { ArrowUp, Heart, Linkedin, Mail, Phone, Globe } from "lucide-react"

const footerLinks = {
  navigation: [
    { label: "Home", href: "#home" },
    { label: "About", href: "#about" },
    { label: "Skills", href: "#skills" },
    { label: "Projects", href: "#projects" },
    { label: "Services", href: "#services" },
    { label: "Contact", href: "#contact" },
  ],
  social: [
    { 
      label: "LinkedIn", 
      href: "https://www.linkedin.com/in/dhruvi-kathrotiya-9b4b22299",
      icon: Linkedin 
    },
    { 
      label: "Email", 
      href: "mailto:workdhruvi123@gmail.com",
      icon: Mail 
    },
    { 
      label: "Phone", 
      href: "tel:+919016904130",
      icon: Phone 
    },
    { 
      label: "Portfolio", 
      href: "https://techbt67.github.io/portfolio/",
      icon: Globe 
    },
  ],
}

export function Footer() {
  const scrollToTop = () => {
    window.scrollTo({ top: 0, behavior: "smooth" })
  }

  return (
    <footer className="bg-card border-t border-border">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Main Footer Content */}
        <div className="py-16 grid md:grid-cols-2 lg:grid-cols-4 gap-12">
          {/* Brand */}
          <div className="lg:col-span-2">
            <a href="#home" className="text-2xl font-bold gradient-text">
              Dhruvi.
            </a>
            <p className="mt-4 text-muted-foreground max-w-md leading-relaxed">
              UI/UX Designer, Graphic Designer & Web Designer based in Surat, India. 
              Passionate about creating beautiful, user-centered digital experiences.
            </p>
            <div className="flex gap-3 mt-6">
              {footerLinks.social.map((link) => (
                <motion.a
                  key={link.label}
                  href={link.href}
                  target="_blank"
                  rel="noopener noreferrer"
                  whileHover={{ y: -4 }}
                  className="w-10 h-10 rounded-full bg-secondary flex items-center justify-center text-muted-foreground hover:bg-primary hover:text-primary-foreground transition-colors"
                >
                  <link.icon className="w-4 h-4" />
                  <span className="sr-only">{link.label}</span>
                </motion.a>
              ))}
            </div>
          </div>

          {/* Quick Links */}
          <div>
            <h4 className="font-semibold mb-4">Quick Links</h4>
            <ul className="space-y-3">
              {footerLinks.navigation.map((link) => (
                <li key={link.label}>
                  <a
                    href={link.href}
                    className="text-muted-foreground hover:text-primary transition-colors"
                  >
                    {link.label}
                  </a>
                </li>
              ))}
            </ul>
          </div>

          {/* Contact */}
          <div>
            <h4 className="font-semibold mb-4">Contact</h4>
            <ul className="space-y-3 text-muted-foreground">
              <li>
                <a 
                  href="mailto:workdhruvi123@gmail.com"
                  className="hover:text-primary transition-colors"
                >
                  workdhruvi123@gmail.com
                </a>
              </li>
              <li>
                <a 
                  href="tel:+919016904130"
                  className="hover:text-primary transition-colors"
                >
                  +91 9016904130
                </a>
              </li>
              <li>Surat, Gujarat, India</li>
            </ul>
          </div>
        </div>

        {/* Bottom Bar */}
        <div className="py-6 border-t border-border flex flex-col sm:flex-row items-center justify-between gap-4">
          <p className="text-sm text-muted-foreground text-center sm:text-left">
            &copy; {new Date().getFullYear()} Dhruvi Kathroiya. All rights reserved.
          </p>
          <div className="flex items-center gap-2 text-sm text-muted-foreground">
            <span>Made with</span>
            <Heart className="w-4 h-4 text-red-500 fill-red-500" />
            <span>in India</span>
          </div>
        </div>
      </div>

      {/* Scroll to Top Button */}
      <motion.button
        onClick={scrollToTop}
        initial={{ opacity: 0, scale: 0 }}
        animate={{ opacity: 1, scale: 1 }}
        whileHover={{ y: -4 }}
        className="fixed bottom-8 right-8 w-12 h-12 rounded-full gradient-bg text-primary-foreground shadow-lg flex items-center justify-center z-40"
      >
        <ArrowUp className="w-5 h-5" />
        <span className="sr-only">Scroll to top</span>
      </motion.button>
    </footer>
  )
}

import type { Metadata } from 'next'
import { Inter, Geist_Mono } from 'next/font/google'
import { Analytics } from '@vercel/analytics/next'
import { ThemeProvider } from '@/components/theme-provider'
import './globals.css'

const inter = Inter({ 
  subsets: ["latin"],
  variable: '--font-sans',
})

const geistMono = Geist_Mono({ 
  subsets: ["latin"],
  variable: '--font-mono',
})

export const metadata: Metadata = {
  title: 'Dhruvi Kathroiya | UI/UX Designer & Web Designer',
  description: 'Premium portfolio of Dhruvi Kathroiya - UI/UX Designer, Graphic Designer, and Front-End Web Designer based in Surat, India. Designing experiences that people love.',
  keywords: ['UI/UX Designer', 'Graphic Designer', 'Web Designer', 'Figma', 'Portfolio', 'Surat', 'India'],
  authors: [{ name: 'Dhruvi Kathroiya' }],
  openGraph: {
    title: 'Dhruvi Kathroiya | UI/UX Designer & Web Designer',
    description: 'Premium portfolio of Dhruvi Kathroiya - Designing experiences that people love.',
    type: 'website',
  },
}

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode
}>) {
  return (
    <html lang="en" suppressHydrationWarning>
      <body className={`${inter.variable} ${geistMono.variable} font-sans antialiased bg-background`}>
        <ThemeProvider
          attribute="class"
          defaultTheme="dark"
          enableSystem
          disableTransitionOnChange
        >
          {children}
        </ThemeProvider>
        {process.env.NODE_ENV === 'production' && <Analytics />}
      </body>
    </html>
  )
}
